@ytWatchBot
=======

Telegram bot watch youtube cahnnels.
Write to [@ytWatchBot](https://telegram.me/ytWatchBot) and use it!

Run
---
Use node-ytSub_example as the service for init.d or enter in console:

    node dist/main.js
