function assertType<T>(val: any): asserts val is T {}

export default assertType;
