import getDebug from 'debug';

export {getDebug};
