const getNow = () => Math.trunc(Date.now() / 1000);

export default getNow;
