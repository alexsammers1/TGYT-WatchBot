import pLimit from 'p-limit';

const promiseLimit = pLimit;

export default promiseLimit;
